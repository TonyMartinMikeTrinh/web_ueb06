<?php


use CodeIgniter\Model;

class AufgabenplanerModel extends Model
{

    public function getAufgaben($aufgaben_id = null){
        $this->aufgaben = $this->db->table('aufgaben');
        $this->aufgaben->select('*');

        if($aufgaben_id != null){
            $this->aufgaben->where('aufgaben.id',$aufgaben_id);
        }

        if ($aufgaben_id != NULL)
            return $result->getRowArray();
        else
            return $result->getResultArray();
    }

    public function getMitglieder($mitglied_id = null){
        $this->mitlgieder = $this->db->table('mitglied');
        $this->mitlgieder->select('*');

        if($mitglied_id != null){
            $this->mitlgieder->where('mitglied.id',$mitglied_id);
        }

        if ($mitglied_id != NULL)
            return $result->getRowArray();
        else
            return $result->getResultArray();
    }



    public function createMitglied() {

        $this->personen = $this->db->table('mitglied');
        $this->personen->insert(array('vorname' => $_POST['vorname'],
            'name' => $_POST['name'],
            'strasse' => $_POST['strasse'],
            'plz' => $_POST['plz'],
            'ort' => $_POST['ort']));

    }

    public function updateMitglied() {

        $this->personen = $this->db->table('mitglied');
        $this->personen->where('mitglied.id', $_POST['id']);
        $this->personen->update(array('vorname' => $_POST['vorname'],
            'name' => $_POST['name'],
            'strasse' => $_POST['strasse'],
            'plz' => $_POST['plz'],
            'ort' => $_POST['ort']));
    }


    public function deleteMitglied() {
        $this->personen = $this->db->table('mitlgied');
        $this->personen->where('mitglied.id', $_POST['id']);
        $this->personen->delete();
    }



}