<div class="container-fluid ms-4 me-3 p-2">
    <div class="list-group" style="min-width: max-content">

        <div class="list-group-item" style="font-size:calc(4px + 1vw)">
            <a href="login.php" style="text-decoration: none">Login</a>
        </div>

        <div class="list-group-item" style="font-size:calc(4px + 1vw)">
            <a href="projekte.php" style="text-decoration: none">Projekte</a>
        </div>

        <div class="list-group-item" style="font-size:calc(4px + 1vw)">
            <a href="aktuelellesProjekt.php" style="text-decoration: none">Aktuelles Projekt</a>
        </div>

        <div class="list-group-item" style="font-size:calc(4px + 1vw); margin-left: 2vw">
            <a href="reiter.php" style="text-decoration: none">Reiter</a>
        </div>

        <div class="list-group-item" style="font-size:calc(4px + 1vw); margin-left: 2vw">
            <a href="aufgaben.php" style="text-decoration: none">Aufgaben</a>
        </div>

        <div class="list-group-item" style="font-size:calc(4px + 1vw); margin-left: 2vw">
            <a href="personen.php" style="text-decoration: none">Mitglieder</a>
        </div>

    </div>

</div>


