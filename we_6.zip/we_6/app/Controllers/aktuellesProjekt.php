<?php

namespace App\Controllers;

use App\Models\AufgabenplanerModel;


class aktuellesProjekt extends BaseController
{

    public function __construct() {
        $this->AufgabenplanerModel = new AufgabenplanerModel();
    }

    public function index() //aktuelelles Projekt
    {
        $data['titel'] = "Aufgabenplaner: akutelles Projekt";

        $data['aufgaben'] = $this->AufgabenplanerModel->getAufgaben();
        $data['mitglieder'] = $this->AufgabenplanerModel->getMitglieder();

        //echo var_dump($data['aufgaben']);


        echo view('templates/header', $data);
        echo view('aktuelellesProjekt');
    }
}