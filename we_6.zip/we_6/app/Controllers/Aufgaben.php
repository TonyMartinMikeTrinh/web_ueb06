<?php

namespace App\Controllers;
use App\Models\AufgabenplanerModel;
class Aufgaben extends BaseController
{


    public function __construct() {
        $this->AufgabenplanerModel = new AufgabenplanerModel();
    }

    public function index(){ //aufgaben
        $data['titel'] = "Aufgabenplaner: Aufgaben";

        $data['aufgaben'] = $this->AufgabenplanerModel->getAufgaben();
        $data['mitglieder'] = $this->AufgabenplanerModel->getMitglieder();

        echo view('templates/header', $data);
        echo view('aufgaben');

    }

}