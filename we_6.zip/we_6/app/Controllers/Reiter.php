<?php

namespace App\Controllers;
use App\Models\AufgabenplanerModel;
class Reiter extends BaseController
{


    public function __construct() {
        $this->AufgabenplanerModel = new AufgabenplanerModel();
    }

    public function index(){
        $data['titel'] = "Aufgabenplaner: Reiter";
        $data['aufgaben'] = $this->AufgabenplanerModel->getAufgaben();
        $data['mitglieder'] = $this->AufgabenplanerModel->getMitglieder();
        echo view('templates/header', $data);
        echo view('reiter');
    }

}