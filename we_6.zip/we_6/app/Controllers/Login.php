<?php

namespace App\Controllers;
use App\Models\AufgabenplanerModel;
class Login extends BaseController
{


    public function __construct() {
        $this->AufgabenplanerModel = new AufgabenplanerModel();
    }

    public function index()
    {
        $this->session->set("loggedin", false);
        $data['titel'] = "Aufgabenplaner: Login";
        $data['mitglieder'] = $this->AufgabenplanerModel->getMitglieder();
        echo view('templates/header', $data);
        echo view('login');
    }


    public function aktuellesProjekt(){
        echo view('login');
        echo "test";
    }

}