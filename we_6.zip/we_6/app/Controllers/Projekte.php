<?php

namespace App\Controllers;
use App\Models\AufgabenplanerModel;
class Projekte extends BaseController
{


    public function __construct() {
        $this->AufgabenplanerModel = new AufgabenplanerModel();
    }

    public function index(){ //projekte
        $data['titel'] = "Aufgabenplaner: Projekte";
        $data['aufgaben'] = $this->AufgabenplanerModel->getAufgaben();
        $data['mitglieder'] = $this->AufgabenplanerModel->getMitglieder();
        echo view('templates/header', $data);
        echo view('projekte');
    }

}